__( 'Search or do anything in Elementor', 'elementor' );
__( 'Add-ons', 'elementor' );
__( 'Finder', 'elementor' );
__( 'What\'s New', 'elementor' );
__( 'Connect your account to get access to Elementor\'s Template Library & more.', 'elementor' );
__( 'Connect Account', 'elementor' );
__( 'My Elementor', 'elementor' );