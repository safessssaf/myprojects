__( 'Sign Up', 'elementor' );
__( 'Don\'t Show Again', 'elementor' );