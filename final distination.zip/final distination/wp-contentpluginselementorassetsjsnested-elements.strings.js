__( 'Close', 'elementor' );
__( 'Select your Structure', 'elementor' );
__( 'Add new container', 'elementor' );
__( 'Drag widget here', 'elementor' );